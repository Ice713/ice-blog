<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AccountController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('index');
});

Route::get('/sign-in', function () {
    return view('sign-in/index');
});

Route::get('/sign-up', function () {
    return view('sign-up/index');
});

Route::get('/admin', function () {
    return view('admin/index');
});

Route::controller(AccountController::class)->group(function() {
    Route::post('save-account', 'saveAccount'); // url link on ajax, function at controller
    Route::post('/signin-account', 'signinAccount'); // url link on ajax, function at controller
});



