<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class AccountController extends Controller
{
    public function saveAccount(Request $request){

        // $firstname = $request->input('firstname');
        // $lastname = $request->input('lastname');
        // $email = $request->input('email');
        // $password = password_hash($request->input('password'), PASSWORD_DEFAULT);

        // $save = DB::table('user_blog')->insert([
        //     'firstname' => $firstname,
        //     'lastname' => $lastname,
        //     'email' => $email,
        //     'password' => $password
        // ]);

        $save = DB::table('user_blog')->insert([
            'firstname' => $request->input('firstname'),
            'lastname' => $request->input('lastname'),
            'email' => $request->input('email'),
            'password' => password_hash($request->input('password'), PASSWORD_DEFAULT)
        ]);

        return $save ? 1 : 0;
    }

    public function signinAccount(Request $request){
        $email = $request->input('email');
        $password = $request->input('password');

        // Check if user exists
        $user = DB::table('user_blog')->where('email', $email)->first();

        if ($user) {
            // If the user exists, check if the password is correct
            if (password_verify($password, $user->password)) {
                // Password is correct, return 1
                return 1;
            }
        } else {
            
            // If the user doesn't exist or the password is incorrect, return 0
            return 0;
        
        }
            

        
    }
}
