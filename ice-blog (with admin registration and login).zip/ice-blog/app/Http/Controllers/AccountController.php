<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class AccountController extends Controller
{
    public function saveAccount(Request $request){

        // $firstname = $request->input('firstname');
        // $lastname = $request->input('lastname');
        // $email = $request->input('email');
        // $password = password_hash($request->input('password'), PASSWORD_DEFAULT);

        // $save = DB::table('user_blog')->insert([
        //     'firstname' => $firstname,
        //     'lastname' => $lastname,
        //     'email' => $email,
        //     'password' => $password
        // ]);

        $check = DB::table('user_blog')->where('email', $request->input('email'))->first();

        if ($check) {
            return 2;
        } else{
                $save = DB::table('user_blog')->insert([
                'firstname' => $request->input('firstname'),
                'lastname' => $request->input('lastname'),
                'email' => $request->input('email'),
                'password' => password_hash($request->input('password'), PASSWORD_DEFAULT)
            ]);

            return $save ? 1 : 0;
        }
    }

    public function signinAccount(Request $request){
        $email = $request->input('email');
        $password = $request->input('password');

        // Check if user exists
        $user = DB::table('user_blog')->where('email', $email)->first();

        if ($user) {
            // If the user exists, check if the password is correct
            if (password_verify($password, $user->password)) {
                // Password is correct, return 1
                return 1;
            }
        } else {
            
            // If the user doesn't exist or the password is incorrect, return 0
            return 0;
        
        }
        
    }

    public function saveAdminAccount(Request $request){
        $fullname = $request->input('fullname');
        $regusername = $request->input('regusername');
        $regpassword = $request->input('regpassword');

        $check = DB::table('tbl_admin_accounts')->where('username', $regusername)->first();

        if ($check) {
            return 2;
        } else {
            $insert = DB::table('tbl_admin_accounts')->insert([
                'username' => $regusername,
                'password' => password_hash($regpassword, PASSWORD_DEFAULT),
                'fullname' => $fullname
            ]);

            return $insert ? 1 : 0;

        }
    }

    // admin account login
    public function loginAdminAccount(Request $request) {
        //check if username is existing
        $check = DB::table('tbl_admin_accounts')
            ->where('username', '=', $request->username)
            ->first();

            //check if data is not null
            if(!(is_null($check))) {
                // check if the password is correct
                if(password_verify($request->password, $check->password)) {
                    //kung tama ang password
                    return 1;
                } else {
                    //kung mali
                    return 0;
                }
            } else {
                return 0;
            }

    }
}
