-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2023 at 06:11 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ice_blog_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_accounts`
--

CREATE TABLE `tbl_admin_accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_accounts`
--

INSERT INTO `tbl_admin_accounts` (`id`, `username`, `password`, `fullname`, `date_created`) VALUES
(4, 'admin@jack', '$2y$10$MT7nCWIIPMYgj8aWSMDrmOLAAH0Ui6bi88eaqjEpKfXMILHV5E1yi', 'Jack Doe', '2023-05-18 03:56:56'),
(2, 'admin@jane', '$2y$10$Dqd5UiHh6SaIosJ/TReLbehFvJGIrbQI5KIqnsaMrI5aLY9hkBJaq', 'Admin Jane Doe', '2023-05-18 03:55:09'),
(1, 'admin@jd', '$2y$10$eb2OeTdRiZFqsUb0ItOckOTsBv4ex0zBgp/RCT7YyJyaK82e03KOe', 'Admin John Doe', '2023-05-18 03:52:51'),
(5, 'admin@jerry', '$2y$10$pcmrGSlV3kSsMuJD9eL4te5/z5bAteYuGI/NCSUi6AjZ1xoA0U0P2', 'Jerry Doe', '2023-05-18 03:57:29'),
(3, 'admin@jude', '$2y$10$oeWOseBZCGcBDyg8gMqfPuy1M7StvuV./OJLhVTP9S9130v4t.mAe', 'Jude Doe', '2023-05-18 03:55:48'),
(6, 'admin@tom', '$2y$10$RrcxLVvJvumWKC5T.XGhMO6RziJCZjrhuVEfEq7xUfxLGwI/s5B1G', 'Tom Doe', '2023-05-18 03:57:55'),
(7, 'admin@vilchor', '$2y$10$GoUrYixvrM8OwwVu/f3LPePaHrJKj2TFJkzmhZAxHzcjSx7Shpcc2', 'Vilchor Perdido', '2023-05-18 04:05:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_blog`
--

CREATE TABLE `user_blog` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL DEFAULT '0',
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_blog`
--

INSERT INTO `user_blog` (`user_id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'Jane', 'Doe', 'jane@mail.com', '$2y$10$drvbldK9rWHlUQr2xnMT/.pk.vHIUeAgvsV4/E7ot8bn1wUq7wH3i'),
(2, 'Jack', 'Doe', 'jack@mail.com', '$2y$10$lLLVSyWU0SYgCAWUrvaEGOoDWUZN9CUeV.fsvDuvprqN36jQOfvP6'),
(3, 'John', 'Wick', 'wick@mail.com', '$2y$10$QiY7g0r6.8rpnnA3vTAXFulGOM.yzzcx.0cvDR6dUfahUGyQy2TQO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_accounts`
--
ALTER TABLE `tbl_admin_accounts`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `user_blog`
--
ALTER TABLE `user_blog`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_accounts`
--
ALTER TABLE `tbl_admin_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_blog`
--
ALTER TABLE `user_blog`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
